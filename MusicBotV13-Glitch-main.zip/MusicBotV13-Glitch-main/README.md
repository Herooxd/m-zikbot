# Discord.js v13 Müzik Botu
Umut Bayraktar Youtube Özel Discord.js v13 Müzik Botu Altyapısı.<br>
<b>.env</b> İsimli Dosyaya Bot Tokeninizi Yazın ve Kullanın.<br>
<br><br>
Umut Bayraktar Youtube: <a href="https://www.youtube.com/UmutBayraktarYT">Abone Ol</a><br>
Discord: <a href="https://discord.gg/58e5H4try3">Katıl</a>
<br><br>
Code Share Discord: <a href="https://discord.gg/6XGqdgE">KATIL</a>
